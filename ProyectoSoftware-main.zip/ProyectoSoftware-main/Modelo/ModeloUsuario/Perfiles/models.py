from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Perfil():

    @staticmethod
    def crearYGuardar(request):
        user=User.objects.create_user(username=request.POST['username'], password=request.POST['password1'], alergia=request.POST['alergia'])
                
        user.save()
        return user

    @staticmethod
    def enviar_datos():
        return User.objects.all()
    
    @staticmethod
    def borrar(user):
        user.delete()

    def crear(request):
        user2=User.objects.create_user(username=request.POST['username'], password=request.POST['password1'], alergia=request.POST['alergia'])
        return user2

    def guardar(user):
        user.save()