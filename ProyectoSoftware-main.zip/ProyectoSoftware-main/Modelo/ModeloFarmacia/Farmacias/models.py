from django.db import models
from Modelo.ModeloLaboratorio.Laboratorios.models import Laboratorios

class Farmacia(models.Model):
    nombre = models.CharField(max_length=100)
    direccion = models.CharField(max_length=100)
    laboratorios = models.ManyToManyField(Laboratorios, related_name='farmacias')
    
    def __str__(self):
        return self.nombre

    @staticmethod
    def guardar(elemento, formulario):
        elemento.save()
        formulario.save_m2m()

    @staticmethod
    def ordenar(orden):
        if orden == 'alfabetico':
            farmacias = Farmacia.objects.order_by('nombre')
        elif orden == 'reciente':
            farmacias = Farmacia.objects.order_by('-id')
        elif orden == 'laboratorio':
            farmacias = Farmacia.objects.order_by('laboratorios__nombre')
        else:
            farmacias = Farmacia.objects.all()
        return farmacias