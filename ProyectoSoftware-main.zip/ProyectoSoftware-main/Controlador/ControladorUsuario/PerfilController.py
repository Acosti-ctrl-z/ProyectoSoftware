from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.db import IntegrityError
from django.http import HttpResponse
from django.contrib import messages
from Modelo.ModeloUsuario.Perfiles.models import Perfil

# Create your views here.
def home(request):
    return render(request, 'home.html')

def signup(request):

    if request.method =='GET':
        return render(request, 'signup.html',{
        'formUser':UserCreationForm,
    })
    else:
        if request.POST['password1']==request.POST['password2']:
            try:
                user=Perfil.crearYGuardar(request)

                login(request, user)
                return redirect('perfiles')
            except IntegrityError                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     : 
                return render(request, 'signup.html',{
                        'formUser':UserCreationForm,
                        "error":'usuario ya existe'
                    })        
        else:
            return render(request, 'signup.html',{
                'formUser':UserCreationForm,
                "error":'contraseñas no coinciden'
                })

def perfiles(request):
    users= Perfil.enviar_datos()
    return render(request,'perfiles.html', {'users': users})

def signout(request):
    logout(request)
    return redirect('home')

def signin(request):
    if request.method=='GET':
        return render(request, 'signin.html',{
        'form':AuthenticationForm
    })
    else:
        user= authenticate(request, username=request.POST['username'], password=request.POST['password'])
        
        if user is None:
            return render(request, 'signin.html',{
                'form':AuthenticationForm,
                "error": 'Usuario o contraseña incorrectas'})
        else:
            login(request,user)
            return redirect('home')
        
def editar_perfil(request, id):
    user = get_object_or_404(User, pk=id)
    if request.method == 'POST':
        form = UserCreationForm(request.POST, instance=user)
        print("linea66")
        if form.is_valid():
            if request.POST['password1']==request.POST['password2']:
                try:
                    user2=Perfil.crear(request)
                    user2.is_superuser = user.is_superuser
                    Perfil.guardar(user2)
                    Perfil.borrar(user)
                    return redirect('perfiles')
                except IntegrityError                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     : 
                    return render(request,'editar_perfil.html',{'formUser':form,'user':user,
                            'formUser':UserCreationForm,
                            "error":'nombre ya en uso'
                        })        
            else:
                return render(request,'editar_perfil.html',{'formUser':form,'user':user,
                            'formUser':UserCreationForm,
                            "error":'contraseñas no coinciden'
                        })
        else:print("invalid")
    else:
        form = UserCreationForm(instance=user)
        #return redirect('home')
    return render(request,'editar_perfil.html',{'formUser':form,'user':user})

def eliminar_perfil(request, id):
    user = get_object_or_404(User, pk=id)
    if request.method == 'POST':
        Perfil.borrar(user)
        messages.success(request, 'Usuario eliminado correctamente')
        return redirect('home')
    
    return render(request, 'eliminar_perfil.html', {'user': user})